import os
import sys
import math
import shutil
import setproctitle
import make_graph
import numpy as np
import glob

import torch.utils.data as data
import torchbiomed.utils as utils
from my_loader import *


class my_loader(data.Dataset):
    def __init__(self, root = '.', transform=None):

        self.root = root
        self.transform = transform
        self.imgs = sorted(glob.glob(root + 'lung_mask_samesize/*.npy'))
        self.target = sorted(glob.glob(root + 'nodule_mask_samesize/*.npy'))
        if self.imgs is None or self.target is None:
            raise(RuntimeError("images and targets must be set"))
            
    def __getitem__(self, index):
        mask_filename = self.imgs[index]
        nodule_filename = self.target[index]
        mask = np.load(mask_filename)
        nodule = np.load(nodule_filename)
        return mask, nodule

    def __len__(self):
        return len(self.imgs)
        #return 1
 
